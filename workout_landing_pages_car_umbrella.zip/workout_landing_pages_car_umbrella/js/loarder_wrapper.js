window.addEventListener("load", function () {
  $(".loader").hide();
  $("body").removeClass("body_fixed");
});

// document.addEventListener("DOMContentLoaded", function () {
//     var loaderWrapper = document.getElementById("loader-wrapper");
//     loaderWrapper.style.display = "none";
//   });
